---
name: Other Issue
about: Not a bug, nor a feature request!
title: ''
labels: ''
assignees: ''

---

*Note*: We encourage questions about usage of SingularityCE to be made via the Google Group or Slack channels. Other users frequent these communities, and may already have the answer to your question!

See: https://sylabs.io/singularity#community for links.

**Type of issue**
E.g. test problem / technical debt / release tracking

**Description of issue**
Give a concise, but complete description of the issue here, with any information that might be needed to investigate, or act on it.
